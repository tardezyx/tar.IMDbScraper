﻿namespace tar.IMDbScraper.Models {
  public class Keyword {
    public string?        ID            { get; set; }
    public InterestScore? InterestScore { get; set; }
    public string?        Text          { get; set; }
    public string?        URL           { get; set; }
  }
}