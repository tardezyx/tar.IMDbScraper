﻿namespace tar.IMDbScraper.Models {
  public class Genre {
    public string? ID   { get; set; }
    public string? Name { get; set; }
  }
}