﻿namespace tar.IMDbScraper.Models {
  public class Text {
    public string? HtmlText  { get; set; }
    public string? PlainText { get; set; }
  }
}