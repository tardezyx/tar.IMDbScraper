﻿namespace tar.IMDbScraper.Models {
  public class Rating {
    public int?    Votes { get; set; }
    public double? Value { get; set; }
  }
}