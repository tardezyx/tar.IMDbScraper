﻿namespace tar.IMDbScraper.Models {
  public class AlternateVersion {
    public string? ID   { get; set; }
    public Text?   Text { get; set; }
  }
}