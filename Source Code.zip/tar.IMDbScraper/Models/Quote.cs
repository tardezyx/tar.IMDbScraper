﻿namespace tar.IMDbScraper.Models {
  public class Quote {
    public string?        ID            { get; set; }
    public InterestScore? InterestScore { get; set; }
    public Text?          Text          { get; set; }
  }
}