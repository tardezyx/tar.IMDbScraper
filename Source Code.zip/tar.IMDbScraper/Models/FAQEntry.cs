﻿namespace tar.IMDbScraper.Models {
  public class FAQEntry {
    public Text?   Answer    { get; set; }
    public string? ID        { get; set; }
    public bool?   IsSpoiler { get; set; }
    public string? Question  { get; set; }
  }
}