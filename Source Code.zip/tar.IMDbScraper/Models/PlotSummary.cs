﻿namespace tar.IMDbScraper.Models {
  public class PlotSummary {
    public string? Author   { get; set; }
    public string? Category { get; set; }
    public string? ID       { get; set; }
    public Text?   Text     { get; set; }
  }
}