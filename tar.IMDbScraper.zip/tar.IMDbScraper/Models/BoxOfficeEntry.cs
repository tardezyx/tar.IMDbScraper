﻿namespace tar.IMDbScraper.Models {
  public class BoxOfficeEntry {
    public long?   Amount      { get; set; }
    public string? Currency    { get; set; }
    public string? Description { get; set; }
    public string? Notes       { get; set; }
  }
}