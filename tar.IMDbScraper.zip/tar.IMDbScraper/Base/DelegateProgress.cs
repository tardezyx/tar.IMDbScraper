﻿using tar.IMDbScraper.Models;

namespace tar.IMDbScraper.Base {
  public delegate void DelegateProgress(ProgressLog progressLog);
}