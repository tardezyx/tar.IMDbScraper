﻿namespace tar.IMDbScraper.Models {
  public class TechnicalEntry {
    public string? Category     { get; set; }
    public string? PlainSubtext { get; set; }
    public string? PlainText    { get; set; }
  }
}