﻿namespace tar.IMDbScraper.Models {
  public class Certification {
    public Country? Country { get; set; }
    public string?  ID      { get; set; }
    public string?  Rating  { get; set; }
    public string?  Note    { get; set; }
  }
}