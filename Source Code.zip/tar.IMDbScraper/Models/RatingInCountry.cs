﻿namespace tar.IMDbScraper.Models {
  public class RatingInCountry {
    public Country? Country { get; set; }
    public Rating?  Rating  { get; set; }
  }
}