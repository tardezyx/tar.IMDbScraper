﻿namespace tar.IMDbScraper.Models {
  public class Connection {
    public AssociatedTitle? AssociatedTitle { get; set; }
    public string?          Category        { get; set; }
    public string?          Notes           { get; set; }
  }
}