﻿namespace tar.IMDbScraper.Models {
  public class Language {
    public string? ID   { get; set; }
    public string? Name { get; set; }
    public string? URL  { get; set; }
  }
}