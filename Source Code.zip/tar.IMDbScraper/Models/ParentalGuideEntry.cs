﻿namespace tar.IMDbScraper.Models {
  public class ParentalGuideEntry {
    public string? Category  { get; set; }
    public bool?   IsSpoiler { get; set; }
    public Text?   Text      { get; set; }
  }
}