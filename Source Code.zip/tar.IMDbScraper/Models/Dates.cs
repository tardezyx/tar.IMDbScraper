﻿using System;

namespace tar.IMDbScraper.Models {
  public class Dates {
    public DateTime? Begin { get; set; }
    public DateTime? End   { get; set; }
  }
}