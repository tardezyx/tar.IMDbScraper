﻿namespace tar.IMDbScraper.Models {
  public class Severity {
    public int? None     { get; set; }
    public int? Mild     { get; set; }
    public int? Moderate { get; set; }
    public int? Severe   { get; set; }
  }
}